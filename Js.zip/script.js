
  var H1 = document.querySelector("h1");
  var h2 = document.querySelector("h2");
  var btn = document.querySelector("#btn");
  
    var URL = "https://cat-fact.herokuapp.com/facts";

    function getFacts() {
      fetch(URL)
        .then((response) => response.json())
        .then((data) => {
          H1.innerHTML = data[0].text;
          h2.innerHTML = data[1].text;
        });
    }

if(btn){
  btn.addEventListener("click", getFacts);
  btn.addEventListener("dblclick", ()=>{
    H1.style.color = "red";
  });
}

